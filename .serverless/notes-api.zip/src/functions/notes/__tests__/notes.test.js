// src/functions/notes/__tests__/notes.test.js
const { handler: createNoteHandler } = require('../createNote');
const { handler: getNotesHandler } = require('../getNotes');
const { handler: updateNoteHandler } = require('../updateNote');
const { handler: deleteNoteHandler } = require('../deleteNote');
const { handler: restoreNoteHandler } = require('../restoreNote');
const { dynamodb, Tables } = require('../../../utils/dynamodb');
const { v4: uuidv4 } = require('uuid');

// Mock modules
jest.mock('../../../middlewares/auth', () => ({
 commonMiddleware: (handler) => handler
}));

jest.mock('../../../utils/dynamodb', () => ({
 dynamodb: {
   put: jest.fn(),
   get: jest.fn(),
   query: jest.fn(),
   delete: jest.fn()
 },
 Tables: {
   NOTES: 'notes-table',
   DELETED_NOTES: 'deleted-notes-table'
 }
}));

jest.mock('uuid');

jest.mock('../../../utils/validation', () => ({
 noteSchema: {
   validate: jest.fn().mockImplementation(async (data) => {
     if (!data.title || !data.text) {
       throw new Error('Invalid input');
     }
   })
 }
}));

describe('Notes Functions', () => {
 const testUser = {
   email: 'test@example.com'
 };

 const testNote = {
   title: 'Test Note',
   text: 'Test content'
 };

 const createTestEvent = (body = testNote, pathParams = {}) => ({
   body: JSON.stringify(body),
   headers: {
     'Content-Type': 'application/json'
   },
   user: testUser,
   pathParameters: pathParams
 });

 beforeEach(() => {
   jest.clearAllMocks();
   dynamodb.put.mockReturnValue({ promise: () => Promise.resolve() });
   dynamodb.get.mockReturnValue({ promise: () => Promise.resolve({}) });
   dynamodb.query.mockReturnValue({ promise: () => Promise.resolve({ Items: [] }) });
   dynamodb.delete.mockReturnValue({ promise: () => Promise.resolve() });
 });

 describe('Create Note', () => {
   test('should create note successfully', async () => {
     const noteId = 'test-id';
     uuidv4.mockReturnValue(noteId);

     const response = await createNoteHandler(createTestEvent());

     expect(response.statusCode).toBe(201);
     const body = JSON.parse(response.body);
     expect(body).toMatchObject({
       id: noteId,
       userId: testUser.email,
       title: testNote.title,
       text: testNote.text
     });
     expect(dynamodb.put).toHaveBeenCalledWith({
       TableName: Tables.NOTES,
       Item: expect.objectContaining({
         id: noteId,
         userId: testUser.email,
         title: testNote.title,
         text: testNote.text
       })
     });
   });

   test('should reject invalid input', async () => {
     const response = await createNoteHandler(createTestEvent({ title: '', text: '' }));
     expect(response.statusCode).toBe(400);
   });
 });

 describe('Get Notes', () => {
   test('should get user notes', async () => {
     const mockNotes = [{ id: '1', ...testNote }];
     dynamodb.query.mockReturnValue({ 
       promise: () => Promise.resolve({ Items: mockNotes }) 
     });

     const response = await getNotesHandler(createTestEvent());

     expect(response.statusCode).toBe(200);
     expect(JSON.parse(response.body)).toEqual(mockNotes);
     expect(dynamodb.query).toHaveBeenCalledWith({
       TableName: Tables.NOTES,
       KeyConditionExpression: 'userId = :userId',
       ExpressionAttributeValues: { ':userId': testUser.email }
     });
   });
 });

 describe('Update Note', () => {
   const noteId = 'test-id';

   test('should update note successfully', async () => {
     const response = await updateNoteHandler(createTestEvent(testNote, { id: noteId }));

     expect(response.statusCode).toBe(200);
     expect(JSON.parse(response.body)).toMatchObject({
       id: noteId,
       userId: testUser.email,
       title: testNote.title,
       text: testNote.text
     });
     expect(dynamodb.put).toHaveBeenCalledWith({
       TableName: Tables.NOTES,
       Item: expect.any(Object),
       ConditionExpression: 'userId = :userId AND id = :id',
       ExpressionAttributeValues: {
         ':userId': testUser.email,
         ':id': noteId
       }
     });
   });

   test('should handle note not found', async () => {
     dynamodb.put.mockReturnValue({
       promise: () => Promise.reject({ code: 'ConditionalCheckFailedException' })
     });

     const response = await updateNoteHandler(createTestEvent(testNote, { id: noteId }));

     expect(response.statusCode).toBe(404);
     expect(JSON.parse(response.body)).toHaveProperty('error', 'Note not found or unauthorized');
   });
 });

 describe('Delete Note', () => {
   const noteId = 'test-id';
   const mockNote = { id: noteId, ...testNote };

   test('should delete and archive note', async () => {
     dynamodb.get.mockReturnValue({ 
       promise: () => Promise.resolve({ Item: mockNote }) 
     });

     const response = await deleteNoteHandler(createTestEvent(null, { id: noteId }));

     expect(response.statusCode).toBe(200);
     expect(dynamodb.put).toHaveBeenCalledWith({
       TableName: Tables.DELETED_NOTES,
       Item: expect.objectContaining({
         ...mockNote,
         deletedAt: expect.any(String)
       })
     });
     expect(dynamodb.delete).toHaveBeenCalledWith({
       TableName: Tables.NOTES,
       Key: { userId: testUser.email, id: noteId }
     });
   });

   test('should handle note not found', async () => {
     const response = await deleteNoteHandler(createTestEvent(null, { id: noteId }));
     expect(response.statusCode).toBe(404);
   });
 });

 describe('Restore Note', () => {
   const noteId = 'test-id';
   const mockDeletedNote = { 
     id: noteId,
     userId: testUser.email,
     ...testNote,
     deletedAt: new Date().toISOString()
   };

   test('should restore deleted note', async () => {
     dynamodb.get.mockReturnValue({ 
       promise: () => Promise.resolve({ Item: mockDeletedNote }) 
     });

     const response = await restoreNoteHandler(createTestEvent(null, { id: noteId }));

     expect(response.statusCode).toBe(200);
     expect(dynamodb.put).toHaveBeenCalledWith({
       TableName: Tables.NOTES,
       Item: expect.objectContaining({
         id: noteId,
         userId: testUser.email,
         title: testNote.title,
         text: testNote.text
       })
     });
     expect(dynamodb.delete).toHaveBeenCalledWith({
       TableName: Tables.DELETED_NOTES,
       Key: { userId: testUser.email, id: noteId }
     });
   });

   test('should handle deleted note not found', async () => {
     const response = await restoreNoteHandler(createTestEvent(null, { id: noteId }));
     expect(response.statusCode).toBe(404);
   });
 });
});